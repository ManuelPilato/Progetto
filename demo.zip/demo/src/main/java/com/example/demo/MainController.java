package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {

    @FXML
    private Button prenotazione;

    @FXML
    private Button ritiro;

    @FXML
    private Button logout;

    @FXML
    void prenota(MouseEvent event) throws IOException {

        //se l'utente sceglie di effettuare una prenotazione si va nell'apposita pagina
        Stage stage = (Stage) prenotazione.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("prenotazione-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Prenotazione");
        stage.setScene(scene);
    }

    @FXML
    void ritira(MouseEvent event) {

        /*controllo se il ritiro è valido, ovvero se c'è stata una richiesta di prenotazione precedente
        *
        *
        *
        */


        //se l'utente richiede il ritiro si va nell'apposita pagina

    }

    @FXML
    void log_out(MouseEvent event) throws IOException {
        //ritorno al menu di login se clicco il tasto di logout
        Stage stage = (Stage) logout.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Accedi");
        stage.setScene(scene);
    }

}
