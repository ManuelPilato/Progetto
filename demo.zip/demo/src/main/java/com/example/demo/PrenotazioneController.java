package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Optional;
import java.util.ResourceBundle;

public class PrenotazioneController implements Initializable {

    @FXML
    private ChoiceBox<String> operazione;

    @FXML
    private Text data_odierna;

    @FXML
    private Button prenota;



    //formato data: dd/mm/yy
    String data_oggi = LocalDate.now().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        operazione.getItems().addAll("per la prima volta", "scadenza", "furto/smarrimento", "deterioramento");
        data_odierna.setText(data_oggi);
    }



    @FXML
    void popup_show(MouseEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Prenotazione");
        alert.setHeaderText("Documenti necessari per il ritiro:\n");
        alert.setContentText(
                "-Modulo di richiesta compilato\n" +
                "-Marca da bollo\n" +
                "-Ricevuta del versamento\n" +
                "-Due fototessere su sfondo bianco\n" +
                "-Passaporto precedente (se in possesso)");

        Optional<ButtonType> res = alert.showAndWait();
        /*azioni possibili dell'alert
        if(res.isEmpty()){}
        else if(res.get() == ButtonType.OK) {}
        else if(res.get() == ButtonType.CANCEL){}*/

        //ritorno al menu principale dopo aver effettuato la prenotazione
        Stage stage = (Stage) prenota.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Prenotazione");
        stage.setScene(scene);


    }

}
