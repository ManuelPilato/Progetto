package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;

public class RegisterController {

    @FXML
    private TextField nome;

    @FXML
    private TextField cognome;

    @FXML
    private DatePicker data;

    @FXML
    private TextField luogo;

    @FXML
    private TextField cod_fisc;

    @FXML
    private Text errore;

    @FXML
    private Button registrati;

    @FXML
    private Button login;


    @FXML
    void registrati(MouseEvent event) throws IOException {

        //controllo: se nome, cognome, luogo sono nulli o contengono caratteri non alfabetici
        boolean flag = true;
        if(!isAlpha(nome.getText()) || !isAlpha(cognome.getText()) || !isAlpha(luogo.getText())){
            flag = false;
            errore.setText("Dati non validi");
            System.out.println("Errore");
        }


        //controllo data di nascita: non può essere maggiore di oggi
        //data di oggi
        if(data.getValue().isEqual(LocalDate.now()) || data.getValue().isAfter(LocalDate.now())){
            errore.setText("Impossibile selezionare una data maggiore o uguale ad oggi");
            System.out.println("Errore");
            flag = false;
        }

        //controllo codice fiscale: se contiene caratteri non alfanumerici o se è diverso dalla lunghezza stabilita
        if(cod_fisc.getLength() != 16 || !isAlphaNumeric(cod_fisc.getText())){
            flag = false;
            errore.setText("Dati non validi");
            System.out.println("Errore");
        }



        //se tutti i controlli vanno a buon fine vado nella pagina principale
        if(flag) {
            errore.setText("");
            Stage stage = (Stage) registrati.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("main-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Menu");
            stage.setScene(scene);
        }




        /*se il cittadino è minore di 18 anni
        LocalDate now = LocalDate.now();
        int diff = now.getYear() - data.getValue().getYear();
        if(diff < 18){
            errore.setText("Devi essere maggiorenne");
        }
        //anno uguale, controllo mese
        else if(diff == 18){
            diff = now.getMonthValue() - data.getValue().getMonthValue();
            if(diff < 0)
                errore.setText("Devi essere maggiorenne");
            //mese uguale, controllo giorno
            else if(diff == 0){
                diff = now.getDayOfMonth() - data.getValue().getDayOfMonth();
                if(diff <= 0){
                    errore.setText("Devi essere maggiorenne");
                }
            }
        }*/


    }



    @FXML
    void login(MouseEvent event) throws IOException {
        //se si è già regostrati si accede alla pagina di login
        Stage stage = (Stage) login.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Accedi");
        stage.setScene(scene);
    }

    public static boolean isAlpha(String s) { return s != null && !s.isEmpty() && s.matches("^[a-zA-Z]+"); }
    public static boolean isAlphaNumeric(String s) { return s.matches("[a-zA-Z0-9]+"); }

}

